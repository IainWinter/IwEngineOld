#pragma once

#include "IwEngine\Common.h"

namespace Physics {
	enum class IWENGINE_API CollisionDetectionMode {
		CONTINUOUS,
		DISCRETE
	};
}