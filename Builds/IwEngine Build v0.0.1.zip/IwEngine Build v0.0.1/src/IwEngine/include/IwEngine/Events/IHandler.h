#pragma once

namespace Events {
	class IHandler {
	public:
		virtual ~IHandler() {}
	};
}