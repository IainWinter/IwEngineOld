#pragma once

namespace Utility {
	#define ASSERT(x) if(!(x)) __debugbreak();
}