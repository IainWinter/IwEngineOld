#include "IwEngine\Object.h"

Object::AtomicInt Object::_staticId;